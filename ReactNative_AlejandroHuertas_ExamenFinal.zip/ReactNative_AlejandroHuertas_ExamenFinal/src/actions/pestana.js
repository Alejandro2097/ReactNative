export const pestana = (idPestana) => {
    return {
        type: 'pestana',
        payload: idPestana
    };
};
