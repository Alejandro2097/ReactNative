export const itemSeleccionado = (idItem) => {
    return {
        type: 'itemSeleccionado',
        payload: idItem
    };
};
