export * from './getData';
export * from './itemSeleccionado';
export * from './pestana';
