export const getData = (datos) => {
    return {
        type: 'getData',
        payload: datos
    };
};
