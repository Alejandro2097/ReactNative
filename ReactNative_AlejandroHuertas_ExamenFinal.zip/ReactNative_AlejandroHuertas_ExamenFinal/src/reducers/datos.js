import datos from './datos.json';

export default () => datos;
